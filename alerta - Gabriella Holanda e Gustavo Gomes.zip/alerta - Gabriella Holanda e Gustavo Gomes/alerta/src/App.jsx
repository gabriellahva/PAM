import React, { useState } from 'react';
import './App.css'

function App() {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');

  const mostrarPopUp = (e) => {
    e.target.reset();
    
  alert(`Cadastro efetuado com sucesso! \nNome: ${nome} \nE-mail: ${email} \nData de Nascimento: ${dataNascimento}`);
  

  setNome('');
  setEmail('');
  setDataNascimento('');
  };

    return (
      
      <body>
      <div className="page">
        <div className="card">

          <form onSubmit={mostrarPopUp}>
            <h2>Formulário Cadastro</h2>

            <p>Digite seu nome:</p>
            <input className='campo' type='nome' onChange={(e) => setNome(e.target.value)}/>

            <p>Digite seu e-mail:</p>
            <input className='campo' type='email' onChange={(e) => setEmail(e.target.value)}/>

            <p>Insira sua data de nascimento:</p>
            <input className='campo' type='date' onChange={(e) => setDataNascimento(e.target.value)} />

            <div>
            <input className='botao' type='submit' value='Acessar' onClick={mostrarPopUp}  />
            </div>

          </form>
        </div>
      </div>
  
      </body>
    );
  }
  
  
  export default App