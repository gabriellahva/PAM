import './App.css'

function App() {
  return (
    <body>

    <div className="page">
      <div className="card">
        <form>
          <h2>Login</h2>
          <hr />
          <p>Digite seus dados para acessar.</p>
          <input className='campo' type='email' placeholder='Digite seu e-mail' />
          <input className='campo' type='senha' placeholder='Digite sua senha' />
          <a href='#'>Esqueci minha senha</a>
          <input className='botao' type='submit' value='Acessar' />
          <p>Ainda não tem uma conta? <a href='#'> Crie uma agora! </a></p>
        </form>
      </div>
    </div>

    </body>
  );
}

export default App
