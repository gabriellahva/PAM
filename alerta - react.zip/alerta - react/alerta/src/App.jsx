import React from 'react';
import './App.css'

function App() {

  const mostrarPopUp = (e) => {
    alert('Dados enviados com sucesso!');
    e.target.reset();
  };
    return (
      
      <body>
      <div className="page">
        <div className="card">
          <form>
            <h2>Formulário Cadastro</h2>
            <p>Digite seu nome:</p>
            <input className='campo' type='name' />
            <p>Digite seu e-mail:</p>
            <input className='campo' type='email' />
            <p>Insira sua data de nascimento:</p>
            <input className='campo' type='date' />
            <div>
            <input className='botao' type='submit' value='Acessar' onClick={mostrarPopUp}  />
            </div>

          </form>
        </div>
      </div>
  
      </body>
    );
  }
  
  
  export default App